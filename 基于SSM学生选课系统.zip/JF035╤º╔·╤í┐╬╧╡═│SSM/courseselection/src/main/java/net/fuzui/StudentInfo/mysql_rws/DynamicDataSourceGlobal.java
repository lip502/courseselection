package net.fuzui.StudentInfo.mysql_rws;

public enum DynamicDataSourceGlobal {
	READ,WRITE;
}
